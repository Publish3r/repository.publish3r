# Watch content from the WWE Network with Kodi.

If you're having issues with your WWE Network live stream:

- Enter Addon Settings

- Enable Proxy Server