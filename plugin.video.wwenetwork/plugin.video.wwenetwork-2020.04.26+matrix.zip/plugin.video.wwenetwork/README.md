# Watch content from the WWE Network with Kodi. (Kodi 19 Matrix Version)

If you're having issues with your WWE Network live stream:

- Enter Addon Settings

- Enable Proxy Server