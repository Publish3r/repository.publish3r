RytecEPG Downloader for Windows.

- EPG Data for DE, AT, CH, BE, DK, ES, FR, IT, NL, UK, FI, NO and SE

- Please run only 2-3 times a week

Recommended EPG Project:

- easyEPG https://github.com/sunsettrack4/easyepg
